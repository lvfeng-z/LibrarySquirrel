const id = "com.lvfeng.pixivSuite.001594e7-dea2-5774-854f-7ac9950e04a0";
const name = "pixivSuite";
const version = "1.0.0";
const author = "lvfeng";
const description = "Library Squirrel的pixiv套件";
const contributes = [
  "taskHandler",
  "siteBrowser"
];
const activation = {
  type: "startup"
};
const entryFile = "pixivSuite.mjs";
const pixivSuiteManifest = {
  id,
  name,
  version,
  author,
  description,
  contributes,
  activation,
  entryFile
};
const ipcChannels = {
  handleShiftNavigation: `${pixivSuiteManifest.id}-handle-shift-navigation`
};
function listenerRegExps() {
  return [
    /^https:\/\/www.pixiv.net\/artworks\/(unlisted)\/([a-z\d]+)/i,
    /^https:\/\/www.pixiv.net\/illust_id=(\d+)/i,
    /^https:\/\/www.pixiv.net\/artworks\/(\d+)/i
  ];
}
export {
  ipcChannels as i,
  listenerRegExps as l,
  pixivSuiteManifest as p
};
