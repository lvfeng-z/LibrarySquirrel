import PixivTaskHandler, { a as axios } from "./pixivTaskHandler.mjs";
import { p as pixivSuiteManifest } from "./assets/ipcChannels-BQ0_E8Dg.js";
import PixivSiteBrowser from "./pixivSiteBrowser.mjs";
import { l as listenerRegExps } from "./assets/listenerRegExps-Dn1zaBM5.js";
import * as path from "node:path";
import "node:fs";
import "util";
import "stream";
import "path";
import "http";
import "https";
import "url";
import "fs";
import "crypto";
import "http2";
import "assert";
import "tty";
import "zlib";
import "events";
import "node:stream";
import "querystring";
import "electron";
class PixivTokens {
  /**
   * 令牌
   */
  accessToken;
  /**
   * 刷新令牌
   */
  refreshToken;
  /**
   * 过期时间
   */
  expiresIn;
  /**
   * 令牌类型
   */
  tokenType;
  /**
   * 权限范围
   */
  scope;
  /**
   * 最后一次刷新时间
   */
  lastRefresh;
  constructor(accessToken, refreshToken, expiresIn, tokenType, scope, lastRefresh) {
    this.accessToken = accessToken;
    this.refreshToken = refreshToken;
    this.expiresIn = expiresIn;
    this.tokenType = tokenType;
    this.scope = scope;
    this.lastRefresh = Date.now();
  }
}
class AccessTokenRefreshFailed extends Error {
  constructor(messageOrError) {
    if (messageOrError instanceof Error) {
      super(messageOrError.message);
    } else {
      super(messageOrError);
    }
    this.name = "AccessTokenRefreshFailed";
    if (Error.captureStackTrace) {
      Error.captureStackTrace(this, this.constructor);
    }
  }
}
class LoginFailed extends Error {
  constructor(messageOrError) {
    if (messageOrError instanceof Error) {
      super(messageOrError.message);
    } else {
      super(messageOrError);
    }
    this.name = "LoginFailed";
    if (Error.captureStackTrace) {
      Error.captureStackTrace(this, this.constructor);
    }
  }
}
class LoginInterrupted extends LoginFailed {
  constructor(messageOrError) {
    if (messageOrError instanceof Error) {
      super(messageOrError.message);
    } else {
      super(messageOrError);
    }
    this.name = "LoginInterrupted";
    if (Error.captureStackTrace) {
      Error.captureStackTrace(this, this.constructor);
    }
  }
}
class PixivLogin {
  static LOGIN_URL = "https://app-api.pixiv.net/web/v1/login";
  static REDIRECT_URI = "https://app-api.pixiv.net/web/v1/users/auth/pixiv/callback";
  static TOKEN_URL = "https://oauth.secure.pixiv.net/auth/token";
  static CLIENT_ID = "MOBrBDS8blbauoSck0ZfDbtuzpyT";
  static CLIENT_SECRET = "lsACyCD94FhDUtGTXi3QzcFE2uU1hqtDaKeqrdwj";
  static USER_AGENT = "PixivAndroidApp/5.0.234 (Android 11; Pixel 5)";
  app;
  codeVerifier;
  codeChallenge;
  constructor(appApi) {
    this.app = appApi;
    this.codeVerifier = PixivLogin.generateCodeVerifier();
    this.codeChallenge = PixivLogin.generateCodeChallenge(this.codeVerifier);
  }
  /**
   * 弹窗请求用户登录pixiv
   * @return {Promise<PixivTokens>}
   */
  async loginPixiv() {
    const clientAuthCode = await this.getClientAuthCode();
    return this.exchangeToken(clientAuthCode);
  }
  /**
   * 获取客户端授权code
   * @return {Promise<string>}
   */
  async getClientAuthCode() {
    return new Promise((resolve, reject) => {
      const loginWindow = this.app.createWindow();
      const timeoutMs = 5 * 60 * 1e3;
      const timeout = setTimeout(() => {
        if (!authCode) {
          loginWindow.close();
          reject(new LoginInterrupted("登录超时"));
          clearTimeout(timeout);
          loginWindow.removeAllListeners();
        }
      }, timeoutMs);
      let authCode;
      loginWindow.webContents.on("will-redirect", (event, newUrl) => {
        if (newUrl.startsWith("pixiv://")) {
          try {
            const urlObj = new URL(newUrl);
            authCode = urlObj.searchParams.get("code");
          } catch (err) {
            loginWindow.close();
            reject(new LoginFailed(err));
            clearTimeout(timeout);
            loginWindow.removeAllListeners();
          }
          if (authCode) {
            event.preventDefault();
            loginWindow.close();
            resolve(authCode);
          } else {
            loginWindow.close();
            reject(new LoginFailed("pixiv://请求中没有找到code"));
          }
          clearTimeout(timeout);
          loginWindow.removeAllListeners();
        }
      });
      loginWindow.on("close", () => {
        clearTimeout(timeout);
        if (!authCode) {
          reject(new LoginInterrupted("用户取消登录"));
          clearTimeout(timeout);
          loginWindow.removeAllListeners();
        }
      });
      this.codeChallenge.then((codeChallengeResult) => {
        const finalUrl = PixivLogin.LOGIN_URL + `?code_challenge=${codeChallengeResult}&code_challenge_method=S256&client=pixiv-android&redirect_uri=${PixivLogin.REDIRECT_URI}`;
        loginWindow.loadURL(finalUrl);
      });
    });
  }
  /**
   * 从认证服务换取token
   * @param clientAuthCode 客户端授权code
   * @return {Promise<PixivTokens>}
   */
  async exchangeToken(clientAuthCode) {
    const body = {
      "client_id": PixivLogin.CLIENT_ID,
      "client_secret": PixivLogin.CLIENT_SECRET,
      "grant_type": "authorization_code",
      "code": clientAuthCode,
      "code_verifier": this.codeVerifier,
      "redirect_uri": PixivLogin.REDIRECT_URI,
      "include_policy": "true"
    };
    const headers = {
      "User-Agent": PixivLogin.USER_AGENT,
      "Content-Type": "application/x-www-form-urlencoded"
    };
    const response = await axios.post(PixivLogin.TOKEN_URL, body, { headers });
    return new PixivTokens(
      response.data.access_token,
      response.data.refresh_token,
      response.data.expires_in,
      response.data.token_type,
      response.data.scope
    );
  }
  /**
   * 从认证服务刷新token
   * @param refreshToken 刷新令牌
   * @return {Promise<PixivTokens>}
   */
  static async refreshToken(refreshToken) {
    const body = {
      "client_id": PixivLogin.CLIENT_ID,
      "client_secret": PixivLogin.CLIENT_SECRET,
      "grant_type": "refresh_token",
      "include_policy": "true",
      "refresh_token": refreshToken
    };
    const headers = {
      "User-Agent": PixivLogin.USER_AGENT,
      "Content-Type": "application/x-www-form-urlencoded"
    };
    try {
      const response = await axios.post(PixivLogin.TOKEN_URL, body, { headers });
      return new PixivTokens(
        response.data.access_token,
        response.data.refresh_token,
        response.data.expires_in,
        response.data.token_type,
        response.data.scope
      );
    } catch (error) {
      const systemError = error.response?.data?.errors?.system;
      const errorCode = systemError?.code;
      const errorMsg = systemError?.message;
      const msg = "刷新token失败！" + errorMsg;
      if ([1508].includes(errorCode)) {
        throw new AccessTokenRefreshFailed(msg);
      } else {
        throw new Error(msg);
      }
    }
  }
  /**
   * 生成 code_verifier (长度为 64 的 URL 安全 Base64 字符串)
   * @return {string}
   */
  static generateCodeVerifier() {
    const array = new Uint8Array(64);
    crypto.getRandomValues(array);
    return btoa(String.fromCharCode(...array)).replace(/\+/g, "-").replace(/\//g, "_").replace(/=/g, "");
  }
  /**
   * 从 code_verifier 生成 code_challenge (SHA-256 哈希后 base64url 编码)
   * @param codeVerifier
   * @return {Promise<string>}
   */
  static async generateCodeChallenge(codeVerifier) {
    const encoder = new TextEncoder();
    const data = encoder.encode(codeVerifier);
    const hashBuffer = await crypto.subtle.digest("SHA-256", data);
    const hashArray = new Uint8Array(hashBuffer);
    return btoa(String.fromCharCode(...hashArray)).replace(/\+/g, "-").replace(/\//g, "_").replace(/=/g, "");
  }
}
class PixivTokenManager {
  /**
   * 主程序api
   * @type AppApi
   */
  app;
  /**
   * pixiv令牌
   * @type PixivTokens
   */
  pixivTokens;
  /**
   * accessToken 加密存储键
   * @type {string|undefined}
   */
  accessTokenKey;
  /**
   * refreshToken 加密存储键
   * @type {string|undefined}
   */
  refreshTokenKey;
  constructor(context, pixivTokens = null) {
    this.app = context.app;
    try {
      const pluginDataObj = JSON.parse(context.pluginData);
      this.accessTokenKey = pluginDataObj.accessTokenKey;
      this.refreshTokenKey = pluginDataObj.refreshTokenKey;
    } catch (ignoredError) {
    }
    this.pixivTokens = pixivTokens || new PixivTokens();
  }
  /**
   * 从加密存储中加载 token
   * @return {Promise<void>}
   */
  async loadTokens() {
    const { app } = this;
    if (this.accessTokenKey) {
      this.pixivTokens.accessToken = await app.getDecryptedValue(this.accessTokenKey);
    }
    if (this.refreshTokenKey) {
      this.pixivTokens.refreshToken = await app.getDecryptedValue(this.refreshTokenKey);
    }
  }
  /**
   * 登录pixiv
   * @return {Promise<number>}
   */
  async loginPixiv() {
    return this.cachePixivToken(await new PixivLogin(this.app).loginPixiv());
  }
  /**
   * 刷新token
   * @return {Promise<PixivTokens>}
   */
  async refreshToken() {
    await this.loadTokens();
    const refreshToken = this.pixivTokens.refreshToken;
    if (refreshToken === void 0) {
      await this.loginPixiv();
      return this.pixivTokens;
    } else {
      try {
        await this.cachePixivToken(await PixivLogin.refreshToken(refreshToken));
      } catch (error) {
        if (error instanceof AccessTokenRefreshFailed) {
          this.app.logger.info(`refreshToken过期或错误，清除缓存的refreshToken，请求用户登录`);
          this.pixivTokens.refreshToken = void 0;
          await this.loginPixiv();
          return this.pixivTokens;
        } else {
          throw error;
        }
      }
    }
  }
  /**
   * 判断token缓存情况，解决认证问题
   * @return {Promise<void>}
   */
  async resolveOAuth() {
    await this.loadTokens();
    const pixivTokens = this.pixivTokens;
    const accessToken = pixivTokens.accessToken;
    const refreshToken = pixivTokens.refreshToken;
    const accessTokenExpired = pixivTokens.lastRefresh + pixivTokens.expiresIn * 1e3 <= Date.now();
    const accessTokenCached = accessToken !== void 0 && accessToken !== null && accessToken !== "";
    const refreshTokenCached = refreshToken !== void 0 && refreshToken !== null && refreshToken !== "";
    if (!accessTokenCached || accessTokenExpired) {
      let msg;
      if (accessTokenExpired) {
        msg = "缓存的accessToken已过期";
      } else {
        msg = "没有缓存的accessToken";
      }
      if (refreshTokenCached) {
        this.app.logger.info(`${msg}，使用refreshToken刷新`);
        await this.refreshToken();
      } else {
        this.app.logger.info(`${msg}，没有缓存的refreshToken，请求用户进行登录`);
        await this.loginPixiv();
      }
    }
  }
  /**
   * 缓存令牌
   * @param pixivToken {PixivTokens}
   * @return {Promise<number>}
   */
  async cachePixivToken(pixivToken) {
    const { app } = this;
    if (this.accessTokenKey) {
      await app.removeEncryptedValue(this.accessTokenKey);
    }
    if (this.refreshTokenKey) {
      await app.removeEncryptedValue(this.refreshTokenKey);
    }
    const accessTokenKey = await app.storeEncryptedValue(pixivToken.accessToken || "", "Pixiv accessToken");
    const refreshTokenKey = await app.storeEncryptedValue(pixivToken.refreshToken || "", "Pixiv refreshToken");
    this.accessTokenKey = accessTokenKey;
    this.refreshTokenKey = refreshTokenKey;
    this.pixivTokens.accessToken = pixivToken.accessToken;
    this.pixivTokens.refreshToken = pixivToken.refreshToken;
    this.pixivTokens.expiresIn = pixivToken.expiresIn;
    this.pixivTokens.tokenType = pixivToken.tokenType;
    this.pixivTokens.scope = pixivToken.scope;
    this.pixivTokens.lastRefresh = Date.now();
    return app.setPluginData(JSON.stringify({
      accessTokenKey: this.accessTokenKey,
      refreshTokenKey: this.refreshTokenKey
    }));
  }
}
async function pixivSuiteFactory(pluginContext) {
  const manifest = pixivSuiteManifest;
  return new PixivSuite(manifest, pluginContext);
}
class PixivSuite {
  /** 插件清单 */
  manifest;
  /** 插件上下文 */
  context;
  /** 令牌管理器 */
  pixivTokenManagerInstance;
  pixivTaskHandlerInstance;
  pixivSiteBrowserInstance;
  constructor(manifest, pluginContext) {
    this.manifest = manifest;
    this.context = pluginContext;
  }
  /** 激活函数 - 插件加载完成后调用 */
  async activate() {
    try {
      this.context.app.registerUrlListener([{
        contributionId: "main",
        listenerPatterns: listenerRegExps()
      }]);
      this.context.app.logger.info("已注册任务url监听器");
      await this.context.app.registerSiteBrowser({
        contributionId: "main",
        pluginPublicId: this.manifest.id,
        name: "PixivSiteBrowser"
      });
      this.context.app.logger.info("已注册站点浏览器");
      const siteBrowserSlotId = `${this.manifest.id}-site-browser-list`;
      const pluginRoot = this.context.app.getPluginRoot(true);
      this.context.slots.registerSiteBrowserSlot({
        slotId: siteBrowserSlotId,
        contributionId: "main",
        pluginPublicId: this.manifest.id,
        name: "PixivSiteBrowser",
        imagePath: `${pluginRoot}/siteBrowserIcon.png`,
        order: 0
      });
      this.context.app.logger.info("已注册站点浏览器列表插槽");
      this.registerDemoViewSlot();
    } catch (error) {
      this.context.app.logger.error("激活失败，", error);
      throw error;
    }
  }
  /** 注册 Demo 视图插槽 */
  registerDemoViewSlot() {
    try {
      const pluginRoot = this.context.app.getPluginRoot(true);
      const slotId = `${this.manifest.id}-demo-view`;
      const componentPath = `${pluginRoot}/PixivDemoView.vue`;
      this.context.slots.registerViewSlot({
        slotId,
        name: "Pixiv 测试视图",
        order: 100,
        contentType: "vueSource",
        content: componentPath
      });
      this.context.app.logger.info("已注册 Demo 视图插槽, 组件路径:", componentPath);
      this.context.slots.registerMenuSlot({
        slotId: `${slotId}-menu`,
        name: "Pixiv 测试",
        icon: "Picture",
        order: 100,
        viewId: slotId
      });
      this.context.app.logger.info("已注册 Demo 菜单插槽");
    } catch (error) {
      this.context.app.logger.error("注册 Demo 视图插槽失败:", error);
    }
  }
  /** 停用函数 - 插件卸载前调用 */
  async deactivate() {
    this.context.app.unregisterUrlListener();
    this.context.app.unregisterSiteBrowser("main");
    const siteBrowserSlotId = `siteBrowser-${this.manifest.id}-main`;
    this.context.slots.unregisterSlot(siteBrowserSlotId);
    const viewId = `plugin-${this.manifest.id}-demo`;
    this.context.slots.unregisterSlot(viewId);
    this.context.slots.unregisterSlot(`menu-${viewId}`);
    this.pixivTaskHandlerInstance = null;
    this.pixivSiteBrowserInstance = null;
    this.pixivTokenManagerInstance = null;
    this.context.app.logger.info("已停用");
  }
  /** 安装后钩子 */
  async onInstall(_type, _oldManifest) {
  }
  /**
   * 获取贡献点实例
   * @param key
   * @param _contributionId
   * @param options { { returnFilePath: boolean } }
   * @returns {undefined|*}
   */
  getContribution(key, _contributionId, options) {
    if (key === "taskHandler") {
      if (options?.returnFilePath) {
        return path.join(this.context.app.getPluginRoot(false), "pixivTaskHandler.mjs");
      } else {
        if (!this.pixivTokenManagerInstance) {
          this.pixivTokenManagerInstance = new PixivTokenManager(this.context);
        }
        if (!this.pixivTaskHandlerInstance) {
          this.pixivTaskHandlerInstance = new PixivTaskHandler(this.pixivTokenManagerInstance);
        }
        return this.pixivTaskHandlerInstance;
      }
    }
    if (key === "siteBrowser") {
      if (options?.returnFilePath) {
        return path.join(this.context.app.getPluginRoot(false), "pixivSiteBrowser.mjs");
      } else {
        if (!this.pixivTokenManagerInstance) {
          this.pixivTokenManagerInstance = new PixivTokenManager(this.context);
        }
        if (!this.pixivSiteBrowserInstance) {
          this.pixivSiteBrowserInstance = new PixivSiteBrowser(this.pixivTokenManagerInstance);
        }
        return this.pixivSiteBrowserInstance;
      }
    }
    return void 0;
  }
}
export {
  pixivSuiteFactory as default
};
