<script>
import { ElCard, ElButton, ElDivider, ElMessage } from "element-plus"

export default {
  setup() {
    // 变量
    const apis = {
      pluginQueryPage: window.api.pluginQueryPage
    }

    // 方法
    // 分页查询插件
    async function pluginQueryPage() {
      return apis.pluginQueryPage({pageSize: 10, pageNumber: 1})
    }

    async function handleClick() {
      const pluginPage = await pluginQueryPage()
      const names = pluginPage.data.data.map((plugin) => plugin.name).join(',')
      ElMessage.success(`插件: ${names}`)
    }

    return {
      apis,
      pluginQueryPage,
      handleClick
    }
  }
}
</script>

<template>
  <div class="pixiv-demo-view">
    <el-card class="demo-card">
      <template #header>
        <div class="card-header">
          <span>Pixiv 插件视图测试</span>
        </div>
      </template>
      <div class="demo-content">
        <p>欢迎使用 Pixiv 插件视图插槽！</p>
        <el-button type="primary" @click="handleClick">点击查询插件列表</el-button>
        <el-divider />
      </div>
    </el-card>
  </div>
</template>

<style>
.pixiv-demo-view {
  padding: 20px;
}

.pixiv-demo-view .demo-content {
  text-align: center;
}
</style>
