const id = "com.lvfeng.pixivSuite_001594e7-dea2-5774-854f-7ac9950e04a0";
const name = "pixivSuite";
const version = "1.0.0";
const author = "lvfeng";
const description = "Library Squirrel的pixiv套件";
const contributes = [
  "taskHandler",
  "siteBrowser"
];
const activation = {
  type: "startup"
};
const entryFile = "pixivSuite.mjs";
const pixivSuiteManifest = {
  id,
  name,
  version,
  author,
  description,
  contributes,
  activation,
  entryFile
};
const ipcChannels = {
  handleShiftNavigation: `${pixivSuiteManifest.id}-handle-shift-navigation`
};
export {
  ipcChannels as i,
  pixivSuiteManifest as p
};
