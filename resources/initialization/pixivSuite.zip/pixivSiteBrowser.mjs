import { ipcMain } from "electron";
import { i as ipcChannels } from "./assets/ipcChannels-BQ0_E8Dg.js";
import * as path from "node:path";
class PixivSiteBrowser {
  /**
   * 令牌管理器
   * @type PixivTokenManager
   */
  tokenManager;
  /**
   * 浏览器窗口实例
   * @type {Electron.BrowserWindow|null}
   */
  browserWindow = null;
  /**
   * pixiv首页URL
   * @type {string}
   */
  static PIXIV_URL = "http://www.pixiv.net/";
  /**
   * 主程序api
   * @type AppApi
   */
  get app() {
    return this.tokenManager.app;
  }
  /**
   * pixiv令牌
   * @type PixivTokens
   */
  get pixivTokens() {
    return this.tokenManager.pixivTokens;
  }
  constructor(tokenManager) {
    this.tokenManager = tokenManager;
    ipcMain.handle(
      ipcChannels.handleShiftNavigation,
      (_event, { url, _target }) => {
        this.app.createTask(url);
      }
    );
  }
  /**
   * 打开pixiv首页
   * @return {Promise<Electron.BrowserWindow>}
   */
  async open() {
    if (this.browserWindow && !this.browserWindow.isDestroyed()) {
      this.browserWindow.focus();
      return this.browserWindow;
    }
    this.browserWindow = this.app.createWindow({
      width: 1400,
      height: 900,
      title: "Pixiv",
      autoHideMenuBar: true,
      webPreferences: {
        nodeIntegration: false,
        contextIsolation: true,
        sandbox: false,
        preload: path.join(this.app.getPluginRoot(false), "pixivSiteBrowserPreload.mjs")
      }
    });
    await this.browserWindow.loadURL(PixivSiteBrowser.PIXIV_URL);
    this.browserWindow.on("closed", () => {
      this.browserWindow = null;
    });
    this.app.logger.info("已打开Pixiv首页");
    return this.browserWindow;
  }
  /**
   * 关闭pixiv浏览器窗口
   * @return {void}
   */
  close() {
    if (this.browserWindow && !this.browserWindow.isDestroyed()) {
      this.browserWindow.close();
      this.browserWindow = null;
      this.app.logger.info("已关闭Pixiv浏览器窗口");
    }
  }
}
export {
  PixivSiteBrowser as default
};
