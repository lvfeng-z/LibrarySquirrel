import { contextBridge, ipcRenderer } from 'electron';

function listenerRegExps() {
    return [
        /^https:\/\/www.pixiv.net\/artworks\/(unlisted)\/([a-z\d]+)/i,
        /^https:\/\/www.pixiv.net\/illust_id=(\d+)/i,
        /^https:\/\/www.pixiv.net\/artworks\/(\d+)/i
    ]
}

var id = "com.lvfeng.pixivSuite.001594e7-dea2-5774-854f-7ac9950e04a0";
var pixivSuiteManifest = {
	id: id};

const ipcChannels = {
    handleShiftNavigation: `${pixivSuiteManifest.id}-handle-shift-navigation`
};

const isTargetUrl = (url) => {
    if (!url) return false
    const regExps = listenerRegExps();
    return regExps.some(regExp => regExp.test(url))
};
contextBridge.exposeInMainWorld('pixivSuite', {
    isLoaded: true,
    debugLog: (msg) => console.log('[Bridge]', msg),
    // 暴露你的 IPC 方法
    sendNavigation: (data) => ipcRenderer.invoke(ipcChannels.handleShiftNavigation, data)
});
window.addEventListener('click', (event) => {
    // 1. 检查是否按下了 Shift 键
    if (!event.shiftKey) {
        return; // 没按 Shift，直接忽略，让页面正常处理
    }

    // 2. 查找最近的 <a> 标签
    const anchor = event.target.closest('a');

    if (anchor && anchor.href) {
        const url = anchor.href;

        // 3. 检查 URL 是否符合格式
        if (isTargetUrl(url)) {
            console.log('[Preload] 拦截到 Shift+Click:', url);

            // 【核心】阻止浏览器默认跳转行为
            event.preventDefault();
            event.stopPropagation();

            // 4. 通知主进程处理后续逻辑
            ipcRenderer.invoke(ipcChannels.handleShiftNavigation, { url, target: anchor.target });
        }
    }

    // 注意：如果是 div/button 通过 JS 跳转 (onclick="location.href=...")
    // 这种很难在 click 阶段拿到最终 URL，通常需要结合 will-navigate (但 will-navigate 拿不到 shiftKey)
    // 对于绝大多数 <a> 标签场景，上面的代码足够了。
}, true);
console.log('[Preload] click 监听中');
