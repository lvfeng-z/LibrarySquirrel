import { contextBridge, ipcRenderer } from "electron";
import { i as ipcChannels, l as listenerRegExps } from "./assets/listenerRegExps-CPlzmro3.js";
const isTargetUrl = (url) => {
  if (!url) return false;
  const regExps = listenerRegExps();
  return regExps.some((regExp) => regExp.test(url));
};
contextBridge.exposeInMainWorld("pixivSuite", {
  isLoaded: true,
  debugLog: (msg) => console.log("[Bridge]", msg),
  // 暴露你的 IPC 方法
  sendNavigation: (data) => ipcRenderer.invoke(ipcChannels.handleShiftNavigation, data)
});
window.addEventListener("click", (event) => {
  if (!event.shiftKey) {
    return;
  }
  const anchor = event.target.closest("a");
  if (anchor && anchor.href) {
    const url = anchor.href;
    if (isTargetUrl(url)) {
      console.log("[Preload] 拦截到 Shift+Click:", url);
      event.preventDefault();
      event.stopPropagation();
      ipcRenderer.invoke(ipcChannels.handleShiftNavigation, { url, target: anchor.target });
    }
  }
}, true);
console.log("[Preload] click 监听中");
