function listenerRegExps() {
  return [
    /^https:\/\/www.pixiv.net\/artworks\/(unlisted)\/([a-z\d]+)/i,
    /^https:\/\/www.pixiv.net\/illust_id=(\d+)/i,
    /^https:\/\/www.pixiv.net\/artworks\/(\d+)/i
  ];
}
export {
  listenerRegExps as l
};
